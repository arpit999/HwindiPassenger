package com.listAdapter.files;

public class Message_user_driver {

	public String messages_user_driver;

	public Message_user_driver(String messages_user_driver) {
		this.messages_user_driver = messages_user_driver;
	}

}
